public interface Comando {
    public void executar();
}